#include <iostream>
#include <stdio.h> 
#include <cstring>
#include <string.h>
#include <stdlib.h>

using namespace std;

int main() 
	{ 
        int x=0;
        cout<<"Please enter a number"<<endl;
        cin>>x;

        int *p= new int[x];
        char **data= new char*[x]; //設置第一個動態陣列

        for(int i=0;i<x;i++)
        {
            data[i]=new char[x];
        }
        
        for(int i=0; i<x;i++) //輸入
        {
            printf("請輸入第%d個字串： ",i+1);
            scanf("%s",data[i]);
        }

        cout<<"-----------------------------------"<<endl;


        for(int i=0;i<x;i++)//輸出
        {   
            cout<<"The number"<<i+1<<" data is: ";
           for(int j=0;j<20;j++)
           {
               if(data[i][j]=='\0')
               {
                   *(p+i)=j; //找出每個字串的長度放到p
                   break;
               }
               cout<<data[i][j];
           }
           cout<<endl;
        }

        cout<<"-----------------------------------"<<endl;

        int a=*(p+0);//找資料中最長的長度
        for(int i=0;i<x;i++)
        {
            if(*(p+i)>a)
            {
                a=*(p+i);
            }
        }

        char **data2;////設置第二個動態二維陣列
        data2=(char**)malloc(sizeof(char*)*x);
        
        for(int i=0;i<x;i++)
        {
            data2[i]=(char*)malloc(sizeof(char)*a);
        }
        
        for(int i=0;i<x;i++)//複製陣列
        {
            strncpy(data2[i], data[i],a); //（目的、來源、長度）
        }
        
        cout<<endl;
        for(int i=0;i<x;i++)//檢查是否複製正確
        {
            if(memcmp(data2[i], data[i],a)==0)
            {
                cout<<"The number "<<i+1<<" data2 is copy correctly"<<endl;
            }
        }

        cout<<"-----------------------------------"<<endl;
        
        for(int i=0;i<x;i++)//釋放第一個陣列
        {
            delete [] data[i];
        }
        delete []data;
        delete []p;
        
        
        int sourses[x];//擺放每一行第一個字元的ASCII code
        
        for(int i=0;i<x;i++)
        {
            sourses[i]=int(*(*(data2+i)+0));
        }
        
        cout<<endl<<"Before Bubble sort  ";//輸出排列前
        for(int i=0;i<x;i++)
        {
            cout<<sourses[i]<<" ";
        }
        cout<<endl;
        
        int *sort=sourses;
        int temp;
        for(int i=0;i<x-1;i++)//Bubble sort 排序 
        {
            for(int j=i+1;j<x;j++)
            {
                if(*(sort+i)>*(sort+j))
                {
                    temp=*(sort+i);
                    *(sort+i)=*(sort+j);
                    *(sort+j)=temp;
                    
                }
            }
        }
        
        cout<<"After Bubble sort  ";//輸出排序後
        for(int i=0;i<x;i++)
        {
            cout<<*(sort+i)<<" ";
        }
        cout<<endl;

        cout<<"-----------------------------------"<<endl;
        
        for(int i=0;i<x;i++)
        {
            for(int j=0;j<x;j++)
            {
                if(*(sort+i)==data2[j][0])
                {
                    cout<<"The number "<<i+1<<" data3 is "<<data2[j]<<endl;
                }
            }
            
        }
        
        
        for(int i=0;i<x;i++)//釋放第二個陣列
        {
            free(data2[i]);
        }
        free(data2);
        




        return 0;
    }