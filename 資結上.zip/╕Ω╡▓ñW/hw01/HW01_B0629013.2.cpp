#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, const char * argv[])
{
    int x = 0;
    cout<<"please enter a number"<<endl;//請使用者輸入要輸入幾份資料
    cin>>x;
    
    char**data=new char*[2*x];//設置動態二維陣列
    
    for(int i=0;i<2*x;i++)
    {
        data[i]=new char[10];
    }
    
    cout<<"please enter a name,do not have a blank and press enter directly"<<endl;
    //請使用者輸入名字，並且不可有空白，每輸入完就按enter
    
    cin.ignore();
    for(int i=0;i<2*x;i++)//輸入
    {
        cin.getline(data[i],15);
    }

    cout<<"-----------------------------------"<<endl;
    for(int i=0;i<2*x;i++)//輸出
    {
        cout<<data[i]<<endl;;
    }
    cout<<endl;

    cout<<"-----------------------------------"<<endl;
    
    int *p=new int[10];
    for(int i=0;i<2*x-1;i=i+2)
    {
        for(int j=0;j<15;j++)
        {
            if(data[i][j]=='\0')
            {
                *(p+i)=j;
                break;
            }
        }
    }
    int a=*(p+0);//找資料中最長的長度
    for(int i=0;i<2*x-1;i=i+2)
    {
        if(*(p+i)>a)
        {
            a=*(p+i);
        }
    }
    
    for(int i=1;i<x;i=i+2)
    {
        for(int j=0;j<15;j++)
        {
            if(data[i][j]=='\0')
            {
                *(p+i)=j;
                break;
            }
        }
    }
    int b=*(p+0);//找資料中最長的長度
    for(int i=1;i<x;i=i+2)
    {
        if(*(p+i)>a)
        {
            b=*(p+i);
        }
    }
    
    
    for(int i=0;i<2*x-1;i=i+2)
    {
        int j=i+1;
        cout<<std::right<<setw(a)<<data[i];//輸出右對齊
        cout<<" ";
        
        cout<<std::left<<data[j];
        cout<<endl;
    }
    
    cout<<endl;
    
    for(int i=0;i<2*x;i++)
    {
        delete  [] data[i];
    }
    delete [] data;
    
    
    return 0;
}
