#include<iostream>

using namespace std;

int main()
{
    int n,i,j,k,x=0;
    cout<<"Please enter a number: ";
    cin>>n;

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            for(k=1;k<=j;k++)
            {
                x++;
            }
        }
    }
    cout<<x<<" times."<<endl;

    return 0;

}