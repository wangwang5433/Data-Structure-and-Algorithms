#include <iostream>

using namespace std;

int main()
{
	int n,i,x=0;
	
	cout<<"Please enter a number. : ";
	cin>>n;
	
	i=1;
	while(i<=n)
	{
		x++;
		i++;
	}
	cout<<x<<" times."<<endl;
	cout<<i<<" times."<<endl;
	
	return 0;
}