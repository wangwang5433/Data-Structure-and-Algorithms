#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <time.h>

using namespace std;

typedef struct Link{
    int exp,coef;
    struct Link* pNext;

};

typedef struct Link* Poly;
typedef struct Link* pLink;

void AddData(Poly p,int _coef,int _exp); //新增資料
void InputData(Poly p); //輸入資料
void LinkMul(Poly A,Poly B,Poly C); //a*b=c
void Print(Poly p); //印出資料
void RemoveCoefZero(Poly p);//將係數為零者去除
void ReleaseLink(Poly p);//釋放記憶體

//新增資料
void AddData(Poly p,int _coef,int _exp)
{
    Poly tmp = p;

    while(tmp->pNext!=NULL) //如果後面有節點
    {
        if(tmp->pNext->exp == _exp)
        {
            //次方一樣，係數直接加進去
            tmp->pNext->coef += _coef;
            return;
        }
        
        else if(tmp->pNext->exp > _exp)
        {
            //次方比現有的小，在前面加節點
            Poly tmp2 = tmp->pNext;
            tmp->pNext = (pLink)malloc(sizeof(struct Link));
            tmp->pNext->exp= _exp;
            tmp->pNext->coef= _coef;
            tmp->pNext->pNext= tmp2;
            return;
        }
        else
        {
            //次方比現有的大，繼續往後找
            tmp = tmp->pNext;
        }
        
    }
    //後面沒找到，生新的節點出來在最後面
    tmp->pNext = (pLink)malloc(sizeof(struct Link));
    tmp->pNext->pNext = NULL;
    tmp->pNext->coef = _coef;
    tmp->pNext->exp = _exp;
}

//印出資料
void Print(Poly p)
{
    Poly tmp = p->pNext;
    if(tmp== NULL)
    {
        printf("多項式為空\n");
        return;
    }
    while(tmp!= NULL)
    {
        if(tmp == p->pNext)
        {
            printf("%dX^%d" , tmp->coef,tmp->exp); //輸出係數、項次
        }
        else 
        {
            printf(" + %dX^%d" , tmp->coef,tmp->exp);
        }
        tmp= tmp->pNext;
    }
    printf("\n");
}

//輸入資料
void InputData(Poly p)
{
    int n=0, i=0;
    int _coef=0, _exp=0;
    printf("請輸入多項式的term數\n");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {   
        printf("輸入第%d項的係數和項次\n", i+1);
        scanf("%d%d",&_coef, &_exp);
        AddData(p, _coef, _exp);
    }
}
/*
//將係數為零者去除
void RemoveCoefZero(Poly p)
{
    Poly pre = p;
    Poly cur = p->pNext;

    while(cur!=NULL)
    {
        if(cur->coef==0)
        {
            pre->pNext= cur->pNext;
            free(cur);
            cur = pre->pNext;
            continue;
        }
        pre= cur;
        cur= cur->pNext;
    }
}
*/
//釋放記憶體
void ReleaseLink(Poly p)
{
    Poly tmp = p->pNext;
    while(tmp!=NULL)
    {
        p->pNext = tmp->pNext;
        free(tmp);
        tmp= p->pNext;
    }
    free(p);
}

//相乘
void LinkMul(Poly A,Poly B,Poly C)
{
    Poly tmpA = A->pNext;
    Poly tmpB = B->pNext;

    double start_time,end_time;
    double total_time = 0;
    double x;
    start_time=clock();
    for(double k=0;k<100000;k++)
    {
        while(tmpA!=NULL)
        {
            tmpB = B->pNext;

            while(tmpB!=NULL)
            {
                AddData(C, tmpA->coef*tmpB->coef, tmpA->exp+tmpB->exp);
                tmpB = tmpB->pNext;
            }
            tmpA = tmpA->pNext;
        }
        x=x+k;
    }
    end_time= clock();
    total_time= (end_time- start_time);
    total_time= double(total_time)/CLOCKS_PER_SEC;
    printf("時間為：%f\n", total_time);
}


int main()
{
    

    int i=0; //initialize
    Poly A,B,C;
    A= (pLink)malloc(sizeof(struct Link));
    A->pNext = NULL;

    B= (pLink)malloc(sizeof(struct Link));
    B->pNext = NULL;

    C= (pLink)malloc(sizeof(struct Link));
    C->pNext = NULL;

    cout<<"=====================輸入A========================"<<endl;
    InputData(A);
    cout<<"=====================輸入B========================"<<endl;
    InputData(B);
    //RemoveCoefZero(A);
    //RemoveCoefZero(B);
    Print(A);
    Print(B);

   
    LinkMul(A,B,C);
       
    //RemoveCoefZero(C);

    Print(C);
    ReleaseLink(A);
    ReleaseLink(B);
   
    return 0;
}
