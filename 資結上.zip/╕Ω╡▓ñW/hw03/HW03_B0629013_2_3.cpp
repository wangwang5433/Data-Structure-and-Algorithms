

#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

class String
{
public:
    void Frequency();//計算字串中每個字母的頻率
    int Length();
    void setString(string a);
    void setWord(char w);
    int f[52]={0};
    void CharDelete();//刪除字串中某字母
private:
    string s;
    char word;
};

int String :: Length()
{
    return s.length();
}

void String::setString(string a)
{
    s=a;
}

void String::setWord(char a)
{
    word=a;
}


void String::Frequency()
{
    string a;
    cout<<"please input a string"<<endl;
    cin>>a;
    setString(a);
    cout<<endl<<a<<endl;
    for(int i=0;i<Length();i++)
    {
        if(s[i]>='a' && s[i]<='z')
            f[s[i]-'a']++;//a=f[0],b=f[1]....計算a.b...有多少
        
    }
    for(int i=0;i<26;i++)
    {
        if(f[i]!=0)
            cout<<char(i+'a')<<" "<<"appeared"<<" "<<f[i]<<"times"<<endl;
    }
    
}

void String::CharDelete()
{
    char w;
    int j=0;
    string b;
    cout<<"please input a word you want to remove"<<endl;
    cin>>w;
    setWord(w);
    for(int i=0;i<Length();i++)
    {
        if(s[i]==word)
        {
            s[i]=' ';
        }
        else
        {
            b[j]=s[i];
            j++;
        }
    }
    
    for(int k=0;k<j;k++)
    {
        cout<<b[k];
    }
        
}


int main()
{
    String b;
    b.Frequency();
    b.CharDelete();
    return 0;
}

