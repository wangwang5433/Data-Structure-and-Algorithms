#include <iostream>

using namespace std;

void CharDelete( string str );
void Frequency( string str );

int main()
{
	string str;
	
	cout<<"�п�J�r��"<<endl;
	cin>>str;

	Frequency(str);	
	CharDelete(str);
}

void Frequency( string str )
{
	int jaja[26];
	int ascii;
	char tmp;
	
	for( int i = 0 ; i < 26 ; i++ )//��l 
	{
		jaja[i] = 0;
	}
	
	for( int i = 0 ; i < str.length() ; i++ )
	{
		ascii = str[i]-97;
		jaja[ascii]++;
	}
	
	for( int i = 0 ; i < 26 ; i++ )
	{
		if( jaja[i] != 0 )
		{
			tmp = i+97;
			cout<<tmp<<"  occured  "<<jaja[i]<<endl;
		}
	}
}

void CharDelete( string str )
{
	char del;
	cout<<"�n�R�����r��:"<<endl; 
	cin>>del;
	
	for( int i = 0 ; i < str.length() ; i++ )
	{
		if( str[i] != del )
		{
			cout<<str[i];
		}
	}
}
	



