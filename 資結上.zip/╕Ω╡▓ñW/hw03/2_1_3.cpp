#include <iostream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

class Currency{
    public:
        Currency();
        Currency(int d, int c);
        Currency operator+(const Money& b) const;

    private:
        int $;
        int cents;
}

Currency::Currency()
{

}

Currency