

#include <iostream>
using namespace std;

class Currency
{
public:
    Currency(int dollar,int cents);
    Currency();
    int value()const;
    int dollar()const;
    int cents()const;
    void set(int dollar,int cents);
    void Multiply(const Currency &t1,float x);//乘以常數
    friend istream & operator>>(istream &input,Currency &t);
    friend ostream & operator<<(ostream &output,Currency &t);
    
private:
    int d;
    float c;
};

Currency::Currency(int dollar,int cents)
{
    d=dollar;
    c=cents;
}
Currency::Currency():d(0),c(0){}

int Currency :: value()const//常函數，const說明函數是不能修改類中成員的值的，只能用於類的成員函數中

{
    return d*100+c;
}

//const說明函數的返回值是不能被修改的
const Currency operator + (const Currency &t1,const Currency &t2)//括號內const常數引用,即不能改變引用的值
{
    int totalmoney=t1.value()+t2.value();
    return Currency(totalmoney/100,totalmoney%100);
}

const Currency operator - (const Currency &t1,const Currency &t2)
{
    int totalmoney=t1.value()-t2.value();
    return Currency(totalmoney/100,totalmoney%100);
}

void Multiply(const Currency &t1)
{
    float mul;
    cout<<"please input a number to multiply"<<endl;
    cin>>mul;
    float totalmoney=t1.value()*mul;
    cout<<"t5"<<endl<<"dollar is"<<int(totalmoney/100)<<endl<<"cents is"<<int(totalmoney-int(totalmoney/100)*100)<<endl;
}

void Currency::set(int dollar, int cents)
{
    d=dollar;
    c=cents;
}

int Currency::dollar()const{return d;}
int Currency::cents()const{return c;}

istream & operator>> (istream &input,Currency &t)
{
    int dollar,cents;
    cout<<"please intput dollar"<<endl;
    input>>dollar;
    cout<<"please input cents"<<endl;
    input>>cents;
    cout<<endl;
    t.set(dollar, cents);
    return input;
}

ostream & operator<< (ostream &output,Currency &t)
{
    output<<"dollar is:"<<t.dollar()<<endl;
    output<<"cents is:"<<t.cents()<<endl;
    return output;
}

int main()
{
    int a;
    cout<<"1 dollar=100cents"<<endl<<endl;
    Currency t1,t2,t3,t4;
    cin>>t1;
    cin>>t2;
    cout<<endl<<endl;
    
    cout<<"t1"<<endl<<t1<<endl;
    cout<<"t2"<<endl<<t2<<endl;
    
    t3=t1+t2;
    t4=t1-t2;
    
    cout<<"t3=t1+t2"<<endl<<t3<<endl;
    
    if(t1.value()<t2.value())
    {
        cout<<"t4=t1-t2 error because t1<t2"<<endl<<endl;
    }
    else
        cout<<"t4=t1-t2"<<endl<<t4<<endl;
    
    cout<<endl;
    cout<<"which data you want to multiply?"<<endl;//選擇資料
    cin>>a;
    if(a==1)
    {
        Multiply(t1);
    }
    else if(a==2)
    {
        Multiply(t2);
    }
    
    return 0;
}
